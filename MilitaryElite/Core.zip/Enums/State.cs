﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefineAnInterfaceIPerson.Enums
{
    public enum State
    {
        inProgress=1,
        Finished=2
    }
}
