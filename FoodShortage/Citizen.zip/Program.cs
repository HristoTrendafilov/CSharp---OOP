﻿using System;
using System.Collections.Generic;

namespace FoodShortage
{
    class Program
    {
        static void Main(string[] args)
        {
            var people = new List<Iperson>();
            var engine = new Engine(people);
            engine.Read();
        }
    }
}
