﻿namespace FoodShortage
{
    internal class list<T>
    {
        public list()
        {
        }
    }
}